package com.sely.assistant

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class ToolsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_tools, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity

        bind(view, R.id.toolCalculator, R.drawable.ic_calculator, "Calculator") { openByCategory(Intent.CATEGORY_APP_CALCULATOR, "calculator") }
        bind(view, R.id.toolTranslator, R.drawable.ic_translate, "Translator") { openWeb("https://translate.google.com") }
        bind(view, R.id.toolDictionary, R.drawable.ic_book, "Dictionary") { openWeb("https://www.google.com/search?q=define") }
        bind(view, R.id.toolNotes, R.drawable.ic_note, "Notes") { openByCategory(Intent.CATEGORY_APP_MESSAGING, "notes") }
        bind(view, R.id.toolWebSearch, R.drawable.ic_globe, "Web Search") { activity.openBrowserSearch() }
        bind(view, R.id.toolYouTube, R.drawable.ic_play, "YouTube") { activity.submitCommand("open youtube", switchToChat = false) }
        bind(view, R.id.toolWhatsApp, R.drawable.ic_bubble, "WhatsApp") { activity.submitCommand("open whatsapp", switchToChat = false) }
        bind(view, R.id.toolChrome, R.drawable.ic_globe, "Chrome") { activity.submitCommand("open chrome", switchToChat = false) }
    }

    private fun bind(root: View, includeId: Int, iconRes: Int, label: String, onClick: () -> Unit) {
        val card = root.findViewById<View>(includeId)
        card.findViewById<ImageView>(R.id.quickActionIcon).setImageResource(iconRes)
        card.findViewById<TextView>(R.id.quickActionLabel).text = label
        card.setOnClickListener { onClick() }
    }

    private fun openByCategory(category: String, friendlyName: String) {
        try {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            val resolved = requireContext().packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            if (resolved != null) {
                startActivity(intent)
            } else {
                Toast.makeText(requireContext(), "No $friendlyName app found on this device", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Couldn't open $friendlyName", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openWeb(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "No browser available", Toast.LENGTH_SHORT).show()
        }
    }
}
