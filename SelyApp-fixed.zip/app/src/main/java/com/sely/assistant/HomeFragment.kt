package com.sely.assistant

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import java.util.Calendar

class HomeFragment : Fragment() {

    private val tips = listOf(
        "\"Knowledge is power. Keep learning, boss!\"",
        "\"Small steps every day build big dreams.\"",
        "\"Ask me anything — I'm always one tap away.\"",
        "\"Say 'Hey Sely' and I'll handle the rest.\""
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity

        val greeting = view.findViewById<TextView>(R.id.homeGreeting)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val timeGreeting = when {
            hour < 12 -> "Good morning"
            hour < 18 -> "Good afternoon"
            else -> "Good evening"
        }
        greeting.text = "$timeGreeting, Boss! \uD83D\uDC51"

        view.findViewById<TextView>(R.id.homeTipText).text =
            tips.random() + "\n\u2014 Sely"

        val askInput = view.findViewById<EditText>(R.id.homeAskInput)
        val askSend = view.findViewById<View>(R.id.homeAskSend)
        val submit = {
            val text = askInput.text.toString().trim()
            if (text.isNotEmpty()) {
                activity.submitCommand(text)
                askInput.setText("")
            }
        }
        askSend.setOnClickListener { submit() }

        bindQuickAction(view, R.id.actionGeneralQuestions, R.drawable.ic_chat, "General\nQuestions") {
            activity.goToChat()
        }
        bindQuickAction(view, R.id.actionStudyHelp, R.drawable.ic_book, "Study\nHelp") {
            (activity.findFragmentTag("chat") as? ChatFragment)?.prefillInput("Help me study: ")
            activity.goToChat()
        }
        bindQuickAction(view, R.id.actionWriteCreate, R.drawable.ic_pencil, "Write &\nCreate") {
            (activity.findFragmentTag("chat") as? ChatFragment)?.prefillInput("Write ")
            activity.goToChat()
        }
        bindQuickAction(view, R.id.actionWebSearch, R.drawable.ic_globe, "Web\nSearch") {
            activity.openBrowserSearch()
        }
        bindQuickAction(view, R.id.actionVoiceChat, R.drawable.ic_mic, "Voice\nChat") {
            startActivity(android.content.Intent(activity, VoiceAssistantActivity::class.java))
        }
        bindQuickAction(view, R.id.actionMoreTools, R.drawable.ic_grid, "More\nTools") {
            activity.goToTools()
        }
    }

    private fun bindQuickAction(root: View, includeId: Int, iconRes: Int, label: String, onClick: () -> Unit) {
        val card = root.findViewById<View>(includeId)
        card.findViewById<ImageView>(R.id.quickActionIcon).setImageResource(iconRes)
        card.findViewById<TextView>(R.id.quickActionLabel).text = label
        card.setOnClickListener { onClick() }
    }
}
