package com.sely.assistant

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import java.util.Locale

class ChatFragment : Fragment(), ChatListener {

    private lateinit var scrollContainer: ScrollView
    private lateinit var chatLog: LinearLayout
    private lateinit var chatInput: EditText
    private lateinit var micButton: ImageButton

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var pendingPrefill: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_chat, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity

        scrollContainer = view.findViewById(R.id.scrollContainer)
        chatLog = view.findViewById(R.id.chatLog)
        chatInput = view.findViewById(R.id.chatInput)
        micButton = view.findViewById(R.id.chatMicButton)
        val sendButton = view.findViewById<View>(R.id.chatSendButton)

        // Render whatever's already in the shared history (e.g. from a previous tab visit).
        chatLog.removeAllViews()
        activity.getChatHistory().forEach { addBubble(it) }
        scrollToBottom()

        pendingPrefill?.let {
            chatInput.setText(it)
            chatInput.setSelection(it.length)
            pendingPrefill = null
        }

        val submit = {
            val text = chatInput.text.toString().trim()
            if (text.isNotEmpty()) {
                activity.submitCommand(text, switchToChat = false)
                chatInput.setText("")
            }
        }
        sendButton.setOnClickListener { submit() }

        micButton.setOnClickListener {
            if (isListening) stopListening() else startListening()
        }
    }

    override fun onResume() {
        super.onResume()
        (requireActivity() as MainActivity).setChatListener(this)
    }

    override fun onPause() {
        (requireActivity() as MainActivity).setChatListener(null)
        stopListening()
        super.onPause()
    }

    /** Called by Home/drawer shortcuts before switching to this tab. */
    fun prefillInput(text: String) {
        if (::chatInput.isInitialized) {
            chatInput.setText(text)
            chatInput.setSelection(text.length)
        } else {
            pendingPrefill = text
        }
    }

    override fun onChatMessageAdded(message: ChatMessage) {
        addBubble(message)
        scrollToBottom()
    }

    private fun addBubble(message: ChatMessage) {
        val bubble = TextView(requireContext()).apply {
            text = message.text
            setTextColor(ContextCompat.getColor(requireContext(), if (message.isUser) android.R.color.white else R.color.text))
            textSize = 14f
            setPadding(36, 24, 36, 24)
            background = ContextCompat.getDrawable(requireContext(), if (message.isUser) R.drawable.bubble_user else R.drawable.bubble_sely)
        }
        val row = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (message.isUser) android.view.Gravity.END else android.view.Gravity.START
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
        }
        bubble.maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
        row.addView(bubble, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        chatLog.addView(row)
    }

    private fun scrollToBottom() {
        scrollContainer.post { scrollContainer.fullScroll(View.FOCUS_DOWN) }
    }

    // ---- Tap-to-talk (single-shot, local-command-first — same routing as the wake service) ----
    private fun startListening() {
        if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(requireContext(), "Microphone permission is needed for voice input", Toast.LENGTH_SHORT).show()
            return
        }
        if (speechRecognizer != null) return

        val recognizer = SpeechRecognizerFactory.create(requireContext())
        if (recognizer == null) {
            Toast.makeText(requireContext(), "Speech recognition isn't available on this device", Toast.LENGTH_SHORT).show()
            return
        }
        speechRecognizer = recognizer
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                micButton.setImageResource(R.drawable.ic_mic)
                micButton.setColorFilter(ContextCompat.getColor(requireContext(), R.color.accent_bright))
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { finishListening() }
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                finishListening()
                if (!text.isNullOrBlank()) {
                    (requireActivity() as MainActivity).submitCommand(text, switchToChat = false)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
        }
        recognizer.startListening(intent)
    }

    private fun finishListening() {
        isListening = false
        micButton.clearColorFilter()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun stopListening() {
        speechRecognizer?.stopListening()
        finishListening()
    }
}
