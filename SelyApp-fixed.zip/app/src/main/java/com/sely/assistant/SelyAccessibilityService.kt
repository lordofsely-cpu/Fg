package com.sely.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Sely's Accessibility Service. It is completely inert until the user turns it on in system
 * Settings, and even then it only acts when a Sely command explicitly calls one of the methods
 * below — it never observes or acts on its own initiative. No rooting, no hidden APIs, no
 * screen recording: everything here is the standard AccessibilityService API surface.
 */
class SelyAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Sely accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally minimal: Sely does not log, store, or transmit event content. This
        // callback exists only because the service must implement it; screen state is read
        // on demand (readScreenText(), etc.), never continuously captured here.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    // ---- Screen awareness ----

    fun currentPackageName(): String? = rootInActiveWindow?.packageName?.toString()

    /** Concatenates visible accessible text/content-descriptions, most useful nodes first. */
    fun readScreenText(maxChars: Int = 1500): String {
        val root = rootInActiveWindow ?: return ""
        val out = StringBuilder()
        collectText(root, out, maxChars)
        return out.toString().trim().take(maxChars)
    }

    private fun collectText(node: AccessibilityNodeInfo, out: StringBuilder, maxChars: Int) {
        if (out.length >= maxChars) return
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrEmpty()) out.append(text).append(". ")
        else if (!desc.isNullOrEmpty()) out.append(desc).append(". ")
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectText(child, out, maxChars)
            child.recycle()
        }
    }

    /** True if any accessible node contains [text] (case-insensitive) — used to verify actions. */
    fun screenContains(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return findNodeByText(root, text) != null
    }

    private fun findNodeByText(root: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val matches = root.findAccessibilityNodeInfosByText(text)
        if (!matches.isNullOrEmpty()) return matches[0]
        // Fallback manual search for content-descriptions (findAccessibilityNodeInfosByText only
        // matches node text, not contentDescription).
        return manualSearch(root, text.lowercase())
    }

    private fun manualSearch(node: AccessibilityNodeInfo, needle: String): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString()?.lowercase()
        if (!desc.isNullOrEmpty() && desc.contains(needle)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = manualSearch(child, needle)
            if (found != null) return found
            child.recycle()
        }
        return null
    }

    // ---- Actions on accessible elements ----

    fun tapByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByText(root, text) ?: return false
        return clickNode(node)
    }

    fun longPressByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByText(root, text) ?: return false
        if (node.actionList.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_LONG_CLICK)) {
            return node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
        }
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        return gestureTap(bounds.centerX().toFloat(), bounds.centerY().toFloat(), longPress = true)
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        // Prefer clicking the node itself, or the nearest clickable ancestor, over a raw
        // coordinate tap — far more reliable across screen densities/layouts.
        var target: AccessibilityNodeInfo? = node
        while (target != null && !target.isClickable) {
            target = target.parent
        }
        if (target != null) {
            return target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        return gestureTap(bounds.centerX().toFloat(), bounds.centerY().toFloat())
    }

    private fun gestureTap(x: Float, y: Float, longPress: Boolean = false): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val duration = if (longPress) 650L else 60L
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun swipe(direction: String): Boolean {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels.toFloat()
        val h = metrics.heightPixels.toFloat()
        val path = Path()
        when (direction.lowercase()) {
            "up" -> path.apply { moveTo(w / 2, h * 0.75f); lineTo(w / 2, h * 0.25f) }
            "down" -> path.apply { moveTo(w / 2, h * 0.25f); lineTo(w / 2, h * 0.75f) }
            "left" -> path.apply { moveTo(w * 0.8f, h / 2); lineTo(w * 0.2f, h / 2) }
            "right" -> path.apply { moveTo(w * 0.2f, h / 2); lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 300)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun scroll(direction: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollable(root) ?: return swipe(direction)
        val action = if (direction.lowercase() == "up") {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }
        return scrollable.performAction(action)
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollable(child)
            if (found != null) return found
            child.recycle()
        }
        return null
    }

    fun typeIntoFocused(text: String): Boolean {
        val focused = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun clearFocusedText(): Boolean {
        val focused = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressEnter(): Boolean {
        val focused = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return focused.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    // ---- Global navigation ----

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun takeScreenshot(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        } else {
            false
        }
    }

    companion object {
        private const val TAG = "SelyAccessibility"
        var instance: SelyAccessibilityService? = null
            private set
        fun isRunning(): Boolean = instance != null
    }
}
