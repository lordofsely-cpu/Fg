package com.sely.assistant

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment() {

    private lateinit var prefs: SharedPreferences

    private val languages = listOf(
        "English" to "en-US",
        "Spanish" to "es-ES",
        "French" to "fr-FR",
        "German" to "de-DE",
        "Portuguese" to "pt-PT",
        "Hindi" to "hi-IN",
        "Arabic" to "ar-SA"
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_settings, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = requireContext().getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)
        val activity = requireActivity() as MainActivity

        setupRow(view, R.id.rowWakeWord, R.drawable.ic_mic, "Wake Word (\"Hey Sely\")",
            if (activity.isWakeServiceRunning) "Always listening in the background" else "Off",
            showSwitch = true, switchChecked = activity.isWakeServiceRunning
        ) { row ->
            row.findViewById<Switch>(R.id.rowSwitch).setOnCheckedChangeListener { _, _ ->
                activity.toggleWakeService()
                row.findViewById<TextView>(R.id.rowSubtitle).text =
                    if (activity.isWakeServiceRunning) "Always listening in the background" else "Off"
            }
        }

        val currentLangLabel = languages.firstOrNull { it.second == (prefs.getString("sely_language", "en-US")) }?.first ?: "English"
        setupRow(view, R.id.rowLanguage, R.drawable.ic_language, "Language", currentLangLabel) { row ->
            row.setOnClickListener { showLanguageDialog(row) }
        }

        setupRow(view, R.id.rowAssistant, R.drawable.ic_assistant, "Default Assistant", "Set Sely as your default assistant") { row ->
            row.setOnClickListener { activity.requestAssistantRole() }
        }

        setupRow(view, R.id.rowPermissions, R.drawable.ic_shield, "Permission Center", "Microphone, Accessibility, and more") { row ->
            row.setOnClickListener { startActivity(Intent(activity, PermissionCenterActivity::class.java)) }
        }

        setupRow(view, R.id.rowRoutines, R.drawable.ic_grid, "Routines", "Custom multi-step commands") { row ->
            row.setOnClickListener { startActivity(Intent(activity, RoutinesActivity::class.java)) }
        }

        setupRow(view, R.id.rowActivityCenter, R.drawable.ic_info, "Activity & Developer Center", "Status, diagnostics, safe test actions") { row ->
            row.setOnClickListener { startActivity(Intent(activity, ActivityCenterActivity::class.java)) }
        }

        setupRow(view, R.id.rowTheme, R.drawable.ic_theme, "Theme", "Dark") { row ->
            row.setOnClickListener {
                Toast.makeText(requireContext(), "Sely looks best in Dark mode. Light theme coming soon!", Toast.LENGTH_SHORT).show()
            }
        }

        setupRow(view, R.id.rowNotifications, R.drawable.ic_bell, "Notifications", "Manage alerts") { row ->
            row.setOnClickListener {
                try {
                    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        intent.putExtra(Settings.EXTRA_APP_PACKAGE, requireContext().packageName)
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Couldn't open notification settings", Toast.LENGTH_SHORT).show()
                }
            }
        }

        setupRow(view, R.id.rowPrivacy, R.drawable.ic_shield, "Privacy & Security", "How Sely handles your data") { row ->
            row.setOnClickListener { showPrivacyDialog() }
        }

        setupRow(view, R.id.rowBackend, R.drawable.ic_cloud, "AI Backend",
            backendSubtitle()
        ) { row ->
            row.setOnClickListener { showBackendDialog(row) }
        }

        setupRow(view, R.id.rowAbout, R.drawable.ic_info, "About Sely", "Version 1.0.0 \u2022 Designed by Kingsley") { row ->
            row.setOnClickListener { showAboutDialog() }
        }
    }

    private fun backendSubtitle(): String {
        val url = prefs.getString("backend_url", "") ?: ""
        return if (url.isEmpty()) "Not configured" else url
    }

    private fun setupRow(
        root: View, includeId: Int, iconRes: Int, title: String, subtitle: String?,
        showSwitch: Boolean = false, switchChecked: Boolean = false,
        configure: (View) -> Unit
    ) {
        val row = root.findViewById<View>(includeId)
        row.findViewById<ImageView>(R.id.rowIcon).setImageResource(iconRes)
        row.findViewById<TextView>(R.id.rowTitle).text = title
        val subtitleView = row.findViewById<TextView>(R.id.rowSubtitle)
        if (!subtitle.isNullOrEmpty()) {
            subtitleView.text = subtitle
            subtitleView.visibility = View.VISIBLE
        } else {
            subtitleView.visibility = View.GONE
        }
        row.findViewById<View>(R.id.rowChevron).visibility = if (showSwitch) View.GONE else View.VISIBLE
        val switchView = row.findViewById<Switch>(R.id.rowSwitch)
        if (showSwitch) {
            switchView.visibility = View.VISIBLE
            switchView.isChecked = switchChecked
        } else {
            switchView.visibility = View.GONE
        }
        configure(row)
    }

    private fun showLanguageDialog(row: View) {
        val labels = languages.map { it.first }.toTypedArray()
        AlertDialog.Builder(requireContext())
            .setTitle("Choose a language")
            .setItems(labels) { _, which ->
                val (label, code) = languages[which]
                (requireActivity() as MainActivity).setSelyLanguage(code)
                row.findViewById<TextView>(R.id.rowSubtitle).text = label
            }
            .show()
    }

    private fun showBackendDialog(row: View) {
        val input = EditText(requireContext())
        input.hint = "https://your-sely-backend.vercel.app"
        input.setText(prefs.getString("backend_url", ""))
        AlertDialog.Builder(requireContext())
            .setTitle("Sely backend URL")
            .setMessage("General questions Sely can't answer locally are sent here. The Gemini key itself lives only on your backend, never in this app.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val url = input.text.toString().trim().trimEnd('/')
                prefs.edit().putString("backend_url", url).apply()
                row.findViewById<TextView>(R.id.rowSubtitle).text = if (url.isEmpty()) "Not configured" else url
                Toast.makeText(requireContext(), "Backend URL saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPrivacyDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Privacy & Security")
            .setMessage(
                "Local commands (opening apps, flashlight, lock, reminders, alarms, calls) run " +
                    "entirely on your device and never leave it.\n\n" +
                    "General questions Sely can't answer locally are sent only to the backend " +
                    "URL you configure, to get an AI answer. Sely never stores or shares your " +
                    "data beyond what's needed to answer your question."
            )
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showAboutDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("About Sely")
            .setMessage("Sely \u2014 Your Smart AI Companion\nVersion 1.0.0\n\nDesigned by Kingsley \uD83D\uDC51")
            .setPositiveButton("Close", null)
            .show()
    }
}
