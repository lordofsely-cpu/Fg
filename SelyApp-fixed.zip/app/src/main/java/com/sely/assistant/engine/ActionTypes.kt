package com.sely.assistant.engine

/**
 * The complete whitelist of actions Sely can execute. Nothing — not local parsing, not the
 * online AI — can make Sely do anything outside this set. [ActionEngine] is the only thing
 * that turns one of these into a real device effect.
 */
enum class ActionType {
    OPEN_APP,
    GO_HOME,
    GO_BACK,
    OPEN_RECENTS,
    TAP,
    LONG_PRESS,
    SWIPE,
    SCROLL_UP,
    SCROLL_DOWN,
    TYPE_TEXT,
    CLEAR_TEXT,
    COPY,
    PASTE,
    SELECT,
    SEARCH,
    PRESS_ENTER,
    WAIT,
    READ_SCREEN,
    TAKE_SCREENSHOT,
    OPEN_URL,
    OPEN_SETTINGS,
    OPEN_SETTINGS_PAGE,
    CONTROL_VOLUME,
    CONTROL_MEDIA,
    CONTROL_FLASHLIGHT,
    CONTROL_BRIGHTNESS,
    SET_ALARM,
    SET_TIMER,
    DEVICE_INFO,
    BATTERY_INFO,
    STORAGE_INFO,
    RUN_ROUTINE,
    CREATE_ROUTINE,
    SHARE_CONTENT,
    STOP_TASK,
    PAUSE_TASK,
    AI_REQUEST,
    WEB_SEARCH,
    UNKNOWN
}

/** One resolved step ready for the Action Engine. [target]/[extra] meaning depends on [type]. */
data class ActionStep(
    val type: ActionType,
    val target: String = "",
    val extra: String = ""
)

/** What actually happened when [ActionEngine] tried to run a step — never assume success. */
data class ActionResult(
    val success: Boolean,
    val message: String,
    val requiresConfirmation: Boolean = false
)

/** How the Command Router classified a raw utterance. */
enum class RequestType {
    PHONE_ACTION,
    LOCAL_TASK,
    AI_REQUEST,
    WEB_REQUEST,
    MIXED_TASK,
    UNKNOWN
}
